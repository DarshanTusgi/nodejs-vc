// Utility functions and helpers will be exported here
export default {};