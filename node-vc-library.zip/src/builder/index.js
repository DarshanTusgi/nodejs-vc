import VCBuilder from './VCBuilder.js';

export {
  VCBuilder
};

export default {
  VCBuilder
};